package logica;

public interface Logica {
	 String executa(HttpServletRequest req,
             HttpServletResponse res) throws Exception;
}
