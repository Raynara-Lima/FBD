package DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;

import JDBC.ConnectionFactory;


import modelo_dao.*;

public class ContatoDao {
	
	private Connection con;

    public ContatoDao() throws ClassNotFoundException {
    	
    }

	public void adiciona(Contato contato) throws ClassNotFoundException  {
        String sql = "insert into contatos " +
                "(nome,email,endereco,dataNascimento)" +
                " values (?,?,?,?)";
        this.con = new ConnectionFactory().getConnection();
        try {
            // prepared statement para inser��o
            PreparedStatement stmt = con.prepareStatement(sql);

            // seta os valores

            stmt.setString(1,contato.getNome());
            stmt.setString(2,contato.getEmail());
            stmt.setString(3,contato.getEndereco());
            stmt.setDate(4, new Date(contato.getDataNascimento().getTimeInMillis()));

            // executa
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
	public ArrayList<Contato> getLista() throws ClassNotFoundException{
		String sql = "SELECT * FROM contatos";
		ArrayList<Contato> lista = new ArrayList<Contato>();
		this.con = new ConnectionFactory().getConnection();
		
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
		
				Contato contato = new Contato();
			
				contato.setNome(rs.getString("nome"));
				contato.setEmail(rs.getString("email"));
				contato.setEndereco(rs.getString("endereco"));
				 Calendar data = Calendar.getInstance();
                 data.setTime(rs.getDate("dataNascimento"));
                 contato.setDataNascimento(data);
				
                 lista.add(contato);
			}
			stmt.close();
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return lista;
		
	}
}
