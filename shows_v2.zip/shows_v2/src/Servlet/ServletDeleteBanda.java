package Servlet;


import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.BandaDao;
import Pojo.Banda;


@WebServlet("/deletarbanda")
public class ServletDeleteBanda extends HttpServlet {
	protected void service(HttpServletRequest request,
			HttpServletResponse response)
					throws IOException, ServletException {
		// busca o writer
		PrintWriter out = response.getWriter();
		
		 String nome = request.getParameter("nomeBanda");
		
		 boolean result = false; 
		BandaDao dao = new BandaDao();
		Banda banda = null;
		try {
			banda = dao.getBandaByName(nome);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			result = dao.deleteBanda(banda.getId_banda());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		out.println("<html>");
		out.println("<body>");
		if(result == true){
			out.println("Banda exclu�do com sucesso");
		}else{
			out.println("N�o foi poss�vel excluir o banda");
		}
		
		
		out.println("</body>");
		out.println("</html>");

}
}
