package Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Pojo.Local;
import DAO.LocalDao;
@WebServlet("/cadastrolocal")
public class ServletCadastroLocal  extends HttpServlet {
	
	    protected void service(HttpServletRequest request,
	                        HttpServletResponse response)
	                        throws IOException, ServletException {
	        // busca o writer
	        PrintWriter out = response.getWriter();

	        // buscando os par�metros no request
	        String nome = request.getParameter("nome");
	        String cap = request.getParameter("capacidade");
	        int capacidade = Integer.parseInt(cap);
	        Local local  = new Local();
	        local.setNome(nome);
	        local.setCapacidade(capacidade);
	        
	        LocalDao dao = new LocalDao();
	        try {
				dao.cadastrarlocal(local);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
	        out.println("<html>");
	        out.println("<body>");
	        out.println("local " + local.getNome() +
	                " cadastrada com sucesso");
	        out.println("</body>");
	        out.println("</html>");
	        
}
}

