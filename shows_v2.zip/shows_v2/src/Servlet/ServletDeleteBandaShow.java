package Servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

import DAO.BandaShowDao;
import DAO.ShowDao;
import Pojo.BandaShow;
import Pojo.Show;

@WebServlet("/deletarbandashow")
public class ServletDeleteBandaShow extends HttpServlet{
	protected void service(HttpServletRequest request,
			HttpServletResponse response)
					throws IOException, ServletException {
		// busca o writer
		PrintWriter out = response.getWriter();

		String dataEmTexto = request.getParameter("data");


		Date data = null;
		// fazendo a convers�o da data
		try {
			Date date = (Date) new SimpleDateFormat("yyyy-mm-DD").parse(dataEmTexto);
			data = date;
		} catch (ParseException e) {
			out.println("Erro de convers�o da data");
			return; //para a execu��o do m�todo
		} catch (java.text.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		boolean result = false; 
		BandaShowDao dao = new BandaShowDao();
		BandaShow bs = null;
		ShowDao sDao = new ShowDao();
		Show show = null;
		try {
			show = sDao.getIdByDate(data);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int id_show = show.getId_show();  
		try {
			bs = dao.getBsByIdShow(id_show);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int id_bs = bs.getId_bandaShow();
		try {
			result = dao.deleteBandaShow(id_bs);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		out.println("<html>");
		out.println("<body>");
		if(result == true){
			out.println("Show exclu�do com sucesso");
		}else{
			out.println("N�o foi poss�vel excluir o show");
		}


		out.println("</body>");
		out.println("</html>");

	}
}
