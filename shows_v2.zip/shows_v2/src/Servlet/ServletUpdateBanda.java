package Servlet;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Pojo.Banda;
import Pojo.Banda.Genero;
import DAO.BandaDao;
@WebServlet("/updatebanda")
public class ServletUpdateBanda extends HttpServlet {
	protected void service(HttpServletRequest request,
			HttpServletResponse response)
					throws IOException, ServletException {
		// busca o writer
		PrintWriter out = response.getWriter();

		// buscando os par�metros no request
		String nome = request.getParameter("nome");
		String nomeBanda = request.getParameter("nomeBanda");
		String genero = request.getParameter("genero");
		
	

		BandaDao dao = new BandaDao();
		Banda banda = null;
		try {
			banda = dao.getBandaByName(nome);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		banda.setNome(nomeBanda);
		banda.setGenero(Genero.valueOf(genero));
		try {
			dao.updateBanda(banda);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		out.println("<html>");
		out.println("<body>");
		out.println("Banda " + banda.getNome() +
				" atualizado com sucesso");
		out.println("</body>");
		out.println("</html>");

	}
}
