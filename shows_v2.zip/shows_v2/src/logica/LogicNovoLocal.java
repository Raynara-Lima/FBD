package logica;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.LocalDao;
import Pojo.Local;;


public class LogicNovoLocal implements Logica{
	public String executa(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		
    String nome = req.getParameter("nome");
    String cap = req.getParameter("capacidade");
    int capacidade = Integer.parseInt(cap);
   
    Local local = new Local();
    local.setNome(nome);
    local.setCapacidade(capacidade);
  
    LocalDao dao = new LocalDao();
	if(dao.cadastrarlocal(local) == true){
		return "mvc?logica=LogicListLocais";
    }else{
    	return "WEB-INF/jsp/erro.jsp";
    }
	
	
}
}