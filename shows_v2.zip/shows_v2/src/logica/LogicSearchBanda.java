package logica;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import DAO.BandaDao;

import Pojo.Banda;

public class LogicSearchBanda implements Logica{
	public String executa(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		
		String chave = req.getParameter("chave");
		ArrayList<Banda> listBandas = new BandaDao().Search(chave);
		req.setAttribute("bandas", listBandas);

		return "WEB-INF/jsp/banda.jsp";

	}
}
