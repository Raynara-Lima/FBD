package logica;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.BandaDao;
import Pojo.Banda;
import Pojo.Banda.Genero;

public class LogicNovaBanda implements Logica{
	public String executa(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		
    String nome = req.getParameter("nome");
    String genero = req.getParameter("genero");
   
    Banda banda = new Banda();
    banda.setNome(nome);
    banda.setGenero(Genero.valueOf(genero));

    BandaDao dao = new BandaDao();
	if(dao.cadastrarBanda(banda) == true){
		return "mvc?logica=LogicListBandas";
    }else{
    	return "WEB-INF/jsp/erro.jsp";
    }
	
	
}
}