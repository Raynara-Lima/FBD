package logica;


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import Pojo.Local;

import DAO.LocalDao;


public class LogicListLocais implements Logica {

	

	public String executa(HttpServletRequest req, HttpServletResponse res)
            throws Exception {
		
		ArrayList<Local> listLocais = new LocalDao().getListLocais();
		 req.setAttribute("locais", listLocais);
		
		
	return "WEB-INF/jsp/local.jsp";
	}

}


