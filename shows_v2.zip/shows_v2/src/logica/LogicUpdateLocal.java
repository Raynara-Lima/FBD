package logica;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.LocalDao;
import Pojo.Local;

public class LogicUpdateLocal implements Logica {
	

	public String executa(HttpServletRequest req, HttpServletResponse res)
            throws Exception {
		
	
		String id = req.getParameter("id");
	    int id_local = Integer.parseInt(id);
	    String nome = req.getParameter("nome");
	    String cap = req.getParameter("capacidade");
	    int capacidade = Integer.parseInt(cap);
	
		Local local = new Local();
	    
		local.setId_local(id_local);
	    local.setNome(nome);
	    local.setCapacidade(capacidade);
	   
	    LocalDao dao = new LocalDao();
	    if(dao.updateLocal(local) == true){
			return "mvc?logica=LogicListLocais";
	    }else{
	    	return "WEB-INF/jsp/erro.jsp";
	    }
	}
}
