package logica;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.LocalDao;
import Pojo.Local;


public class LogicDeleteLocal implements Logica{
	public String executa(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		
	String id_local = req.getParameter("id_local");
    int id = Integer.parseInt(id_local);

    Local local = new Local();
    local.setId_local(id);

    LocalDao dao = new LocalDao();
    if(dao.deleteLocal(id) == true){
		return "mvc?logica=LogicListLocais";
    }else{
    	return "WEB-INF/jsp/erro.jsp";
    }
}
}