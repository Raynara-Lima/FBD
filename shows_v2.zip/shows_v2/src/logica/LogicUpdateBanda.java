package logica;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.BandaDao;
import Pojo.Banda;
import Pojo.Banda.Genero;

public class LogicUpdateBanda implements Logica {
	

	public String executa(HttpServletRequest req, HttpServletResponse res)
            throws Exception {
		
	
		String id = req.getParameter("id");
	    int id_banda = Integer.parseInt(id);
	String nome = req.getParameter("nome");
	String genero = req.getParameter("genero");

	
		Banda banda = new Banda();
	    
		banda.setId_banda(id_banda);
	    banda.setNome(nome);
	    banda.setGenero(Genero.valueOf(genero));
	
	    BandaDao dao = new BandaDao();
	    if(dao.updateBanda(banda) == true){
			return "mvc?logica=LogicListBandas";
	    }else{
	    	return "WEB-INF/jsp/erro.jsp";
	    }
	}
}
