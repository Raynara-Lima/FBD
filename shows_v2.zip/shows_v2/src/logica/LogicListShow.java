package logica;


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import Pojo.Show;

import DAO.ShowDao;;


public class LogicListShow implements Logica {

	

	public String executa(HttpServletRequest req, HttpServletResponse res)
            throws Exception {
		
		ArrayList<Show> listShows = new ShowDao().getListShow();
		 req.setAttribute("shows", listShows);
		
		
	return "WEB-INF/jsp/show.jsp";
	}

}


