package logica;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.BandaDao;
import Pojo.Banda;


public class LogicDeleteBanda implements Logica{
	public String executa(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		
	String id_banda = req.getParameter("id_banda");
    int id = Integer.parseInt(id_banda);

    Banda banda = new Banda();
    banda.setId_banda(id);

    BandaDao dao = new BandaDao();
    if(dao.deleteBanda(id) == true){
		return "mvc?logica=LogicListBandas";
    }else{
    	return "WEB-INF/jsp/erro.jsp";
    }
}
}