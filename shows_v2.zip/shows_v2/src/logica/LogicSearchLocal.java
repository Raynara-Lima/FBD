package logica;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import DAO.LocalDao;

import Pojo.Local;

public class LogicSearchLocal implements Logica{
	public String executa(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		
		String chave = req.getParameter("chave");
		ArrayList<Local> listLocais = new LocalDao().Search(chave);
		req.setAttribute("locais", listLocais);

		return "WEB-INF/jsp/local.jsp";

	}
}
