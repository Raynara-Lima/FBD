package logica;


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import Pojo.Banda;

import DAO.BandaDao;


public class LogicListBandas implements Logica {

	

	public String executa(HttpServletRequest req, HttpServletResponse res)
            throws Exception {
		
		ArrayList<Banda> listBandas = new BandaDao().getListBandas();
		 req.setAttribute("bandas", listBandas);
		
		
	return "WEB-INF/jsp/banda.jsp";
	}

}

