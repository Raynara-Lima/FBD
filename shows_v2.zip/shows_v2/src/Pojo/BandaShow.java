package Pojo;

public class BandaShow {
	private int id_bandaShow;
	private Banda banda;
	private Show show;
	
	
	public BandaShow(){
	;
	}
	
	public Show getShow() {
		return show;
	}
	public void setShow(Show show) {
		this.show = show;
	}
	public Banda getBanda() {
		return banda;
	}
	public void setBanda(Banda banda) {
		this.banda = banda;
	}

	public int getId_bandaShow() {
		return id_bandaShow;
	}

	public void setId_bandaShow(int id_bandaShow) {
		this.id_bandaShow = id_bandaShow;
	}
}
