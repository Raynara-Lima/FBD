package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import JDBC.ConnectionFactory;
import Pojo.Banda;
import Pojo.Banda.Genero;



public class BandaDao {
	private Connection con;
	
	public BandaDao(){
		
	}
	
	public boolean cadastrarBanda(Banda banda) throws ClassNotFoundException  {
        String sql = "insert into banda " +
                "(nome, genero)" +
                " values (?, ?)";
        this.con = new ConnectionFactory().getConnection();
        try {
            // prepared statement para inser��o
            PreparedStatement stmt = con.prepareStatement(sql);

            // seta os valores
           
            stmt.setString(1,banda.getNome());
            stmt.setString(2, banda.toStringGenero());
           
            

    		int affectedRows = stmt.executeUpdate();
			stmt.close();
			
			if(affectedRows > 0) {
				return true;
			}
			return false;
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
    }
	public Banda getByName(String nome) throws ClassNotFoundException{
String sql = "SELECT * FROM banda WHERE nome = ?";
		
		this.con = new ConnectionFactory().getConnection();
		
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, nome);
			
			ResultSet rs = stmt.executeQuery();
			rs.next();
			
			Banda banda = new Banda();
			banda.setId_banda(rs.getInt("id_banda"));
			banda.setNome(rs.getString("nome"));
			banda.setGenero(Genero.valueOf(rs.getString("genero")));
			
			
			stmt.close();
			
			return banda;
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
		
	}
	public Banda getBandaById(int id_banda) throws ClassNotFoundException{
		String sql = "SELECT * FROM banda WHERE id_banda = ?";
		
		this.con = new ConnectionFactory().getConnection();
		
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, id_banda);
			
			ResultSet rs = stmt.executeQuery();
			rs.next();
			
			Banda banda = new Banda();
			banda.setId_banda(rs.getInt("id_banda"));
			banda.setNome(rs.getString("nome"));
		
			
			stmt.close();
			
			return banda;
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	public Banda getBandaByName(String nome) throws ClassNotFoundException{
		String sql = "SELECT * FROM banda WHERE nome = ?";
		
		this.con = new ConnectionFactory().getConnection();
		
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, nome);
			
			ResultSet rs = stmt.executeQuery();
			rs.next();
			
			Banda banda = new Banda();
			banda.setId_banda(rs.getInt("id_banda"));
			banda.setNome(rs.getString("nome"));
			banda.setGenero(Genero.valueOf(rs.getString("genero")));
			
			stmt.close();
			
			return banda;
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
		
		
	}
	
	public ArrayList<Banda> getListBandas() throws ClassNotFoundException{
		String sql = "SELECT * FROM banda";
		ArrayList<Banda> listBandas = new ArrayList<Banda>();
		this.con = new ConnectionFactory().getConnection();
		
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			/*ResultSet � uma interface utilizada pra guardar
			 * dados vindos de um banco de dados.
			*Basicamente, ela guarda o resultado de uma pesquisa
			*numa estrutura de dados que pode ser percorrida,
			*de forma que voc� possa ler os dados do banco. */
			
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {

				Banda banda = new Banda();
				banda.setId_banda(rs.getInt("id_banda"));
				banda.setNome(rs.getString("nome"));
				banda.setGenero(Genero.valueOf(rs.getString("genero")));
				
				listBandas.add(banda);
			}
			stmt.close();
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return listBandas;
		
	}
	public boolean deleteBanda(int id_banda) throws ClassNotFoundException{
		String sql = "DELETE FROM banda WHERE id_banda = ?";
		this.con = new ConnectionFactory().getConnection();
		
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			
			//Setar valores
			stmt.setInt(1, id_banda);
			
			int affectedRows = stmt.executeUpdate();
			stmt.close();
			
			if(affectedRows > 0) {
				return true;
			}
			return false;
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public void updateBanda(Banda banda) throws ClassNotFoundException{
		 String sql = "update banda set nome = ?, genero = ? where id_banda = ?";
	        this.con = new ConnectionFactory().getConnection();
	        try {
	            // prepared statement para inser��o
	            PreparedStatement stmt = con.prepareStatement(sql);

	            // seta os valores

	            stmt.setString(1,banda.getNome());
	            stmt.setString(2,banda.getGenero().name());
	            stmt.setInt(3, banda.getId_banda());
	           
	            

	            // executa
	            stmt.execute();
	            stmt.close();
	        } catch (SQLException e) {
	            throw new RuntimeException(e);
	        }
	}
	
	public ArrayList<Banda> Search(String chave) throws ClassNotFoundException{
		String sql = "SELECT * FROM banda where nome like ?";
		ArrayList<Banda> listBandas = new ArrayList<Banda>();
		this.con = new ConnectionFactory().getConnection();
		
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			
			stmt.setString(1, "%" + chave + "%");
		
	           
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {

				Banda banda = new Banda();
				banda.setId_banda(rs.getInt("id_banda"));
				banda.setNome(rs.getString("nome"));
				banda.setGenero(Genero.valueOf(rs.getString("genero")));
				
				listBandas.add(banda);
			}
			stmt.close();
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return listBandas;
		
	}
}
