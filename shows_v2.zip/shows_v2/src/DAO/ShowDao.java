package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.ArrayList;

import DAO.LocalDao;


import JDBC.ConnectionFactory;
import Pojo.Show;
import Pojo.Local;

public class ShowDao {
	private Connection con;
	public void cadastrarshow(Local local, Show show) throws ClassNotFoundException  {
		String sql = "insert into sw " +
				"(id_local, dataShow)" +
				" values (?, ?)";
		this.con = new ConnectionFactory().getConnection();
		try {
			// prepared statement para inser��o
			PreparedStatement stmt = con.prepareStatement(sql);

			// seta os valores

			stmt.setInt(1,local.getId_local());
			stmt.setDate(2,  new Date( show.getData().getTime()));



			// executa
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public Show getIdByDate(java.util.Date data) throws ClassNotFoundException{
		String sql = "SELECT * FROM sw WHERE dataShow = ?";

		this.con = new ConnectionFactory().getConnection();

		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setDate(1, new Date(data.getTime()));

			ResultSet rs = stmt.executeQuery();
			rs.next();
			LocalDao lDao = new LocalDao();
			Local local = lDao.getLocalById(rs.getInt("id_local"));
			Show show = new Show();

			show.setId_show(rs.getInt("id_show"));
			show.setLocal(local);
			show.setData(rs.getDate("dataShow"));


			stmt.close();

			return show;
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return null;




	}
	public Show getLocalById(int id_show) throws ClassNotFoundException{
		String sql = "SELECT * FROM sw WHERE id_show = ?";

		this.con = new ConnectionFactory().getConnection();

		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, id_show);

			ResultSet rs = stmt.executeQuery();
			rs.next();

			Show show = new Show();
			show.setId_show(rs.getInt("id_show"));
			show.setData(rs.getDate("dataShow"));
			LocalDao lDao = new LocalDao();
			Local local = lDao.getLocalById(rs.getInt("id_local"));
			show.setLocal(local);

			stmt.close();

			return show;
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	public ArrayList<Show> getListShow() throws ClassNotFoundException{
		String sql = "SELECT * FROM sw";
		ArrayList<Show> listShow = new ArrayList<Show>();
		this.con = new ConnectionFactory().getConnection();

		try {
			PreparedStatement stmt = con.prepareStatement(sql);

			LocalDao lDao = new LocalDao();
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {

				Local local = lDao.getLocalById(rs.getInt("id_local"));

				Show show = new Show();
				show.setId_show(rs.getInt("id_show"));
				show.setData(rs.getDate("dataShow"));
				show.setLocal(local);

				listShow.add(show);
			}
			stmt.close();
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return listShow;

	}
	public boolean deleteShow(int id_show) throws ClassNotFoundException{
		String sql = "DELETE FROM sw WHERE id_show = ?";
		this.con = new ConnectionFactory().getConnection();
		try {
			PreparedStatement stmt = con.prepareStatement(sql);

			//Setar valores
			stmt.setInt(1, id_show);

			int affectedRows = stmt.executeUpdate();
			stmt.close();

			if(affectedRows > 0) {
				return true;
			}
			return false;
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}

	public void updateshow(Show show) throws ClassNotFoundException{
		String sql = "update sw set dataShow = ?, id_local = ? where id_show = ?";
		this.con = new ConnectionFactory().getConnection();
		try {
			// prepared statement para inser��o
			PreparedStatement stmt = con.prepareStatement(sql);

			// seta os valores

			stmt.setDate(1, new Date(show.getData().getTime()));
			stmt.setInt(2,show.getLocal().getId_local());
			stmt.setInt(3, show.getId_show());



			// executa
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public Show getShowById(int id_show) throws ClassNotFoundException{
		String sql = "SELECT * FROM sw WHERE id_show = ?";

		this.con = new ConnectionFactory().getConnection();
		LocalDao lDao = new LocalDao();
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, id_show);

			ResultSet rs = stmt.executeQuery();
			rs.next();

			Local local = lDao.getLocalById(rs.getInt("id_local"));

			Show show = new Show();
			show.setId_show(rs.getInt("id_show"));
			show.setData(rs.getDate("dataShow"));
			show.setLocal(local);
			stmt.close();

			return show;
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
}
