package DAO;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import JDBC.ConnectionFactory;
import Pojo.Local;


public class LocalDao {
	private Connection con;
	public void cadastrarlocal(Local local) throws ClassNotFoundException  {
        String sql = "insert into local " +
                "(nome, capacidade)" +
                " values (?, ?)";
        this.con = new ConnectionFactory().getConnection();
        try {
            // prepared statement para inser��o
            PreparedStatement stmt = con.prepareStatement(sql);

            // seta os valores

            stmt.setString(1,local.getNome());
            stmt.setInt(2,local.getCapacidade());
           
            

            // executa
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
	
	public Local getLocalByName(String nome) throws ClassNotFoundException{
		String sql = "SELECT * FROM local WHERE nome = ?";
		
		this.con = new ConnectionFactory().getConnection();
		
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, nome);
			
			ResultSet rs = stmt.executeQuery();
			rs.next();
			
			Local local = new Local();
			local.setId_local(rs.getInt("id_local"));
			local.setNome(rs.getString("nome"));
			local.setCapacidade(rs.getInt("capacidade"));
			
			stmt.close();
			
			return local;
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
		
		
	}
	public Local getLocalById(int id_local) throws ClassNotFoundException{
		String sql = "SELECT * FROM local WHERE id_local = ?";
		
		this.con = new ConnectionFactory().getConnection();
		
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, id_local);
			
			ResultSet rs = stmt.executeQuery();
			rs.next();
			
			Local local = new Local();
			local.setId_local(rs.getInt("id_local"));
			local.setNome(rs.getString("nome"));
			local.setCapacidade(rs.getInt("capacidade"));
			
			stmt.close();
			
			return local;
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	
	public ArrayList<Local> getListLocais() throws ClassNotFoundException{
		String sql = "SELECT * FROM local";
		ArrayList<Local> listLocais = new ArrayList<Local>();
		this.con = new ConnectionFactory().getConnection();
		
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			/*ResultSet � uma interface utilizada pra guardar
			 * dados vindos de um banco de dados.
			*Basicamente, ela guarda o resultado de uma pesquisa
			*numa estrutura de dados que pode ser percorrida,
			*de forma que voc� possa ler os dados do banco. */
			
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
		
				Local local = new Local();
				local.setId_local(rs.getInt("id_local"));
				local.setNome(rs.getString("nome"));
				local.setCapacidade(rs.getInt("capacidade"));
				
				listLocais.add(local);
			}
			stmt.close();
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return listLocais;
		
	}
	public boolean deleteLocal(int id_local) throws ClassNotFoundException{
		String sql = "DELETE FROM local WHERE id_local = ?";
		this.con = new ConnectionFactory().getConnection();
		
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			
			//Setar valores
			stmt.setInt(1, id_local);
			
			int affectedRows = stmt.executeUpdate();
			stmt.close();
			
			if(affectedRows > 0) {
				return true;
			}
			return false;
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public void updateLocal(Local local) throws ClassNotFoundException{
		 String sql = "update local set nome = ?, capacidade = ? where id_local = ?";
	        this.con = new ConnectionFactory().getConnection();
	        try {
	            // prepared statement para inser��o
	            PreparedStatement stmt = con.prepareStatement(sql);

	            // seta os valores

	            stmt.setString(1,local.getNome());
	            stmt.setInt(2,local.getCapacidade());
	            stmt.setInt(3, local.getId_local());
	           
	            

	            // executa
	            stmt.execute();
	            stmt.close();
	        } catch (SQLException e) {
	            throw new RuntimeException(e);
	        }
	}
}
