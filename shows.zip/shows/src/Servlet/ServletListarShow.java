package Servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Pojo.Show;
import DAO.ShowDao;

@WebServlet("/listshow")
public class ServletListarShow extends HttpServlet {
	protected void service(HttpServletRequest request,
			HttpServletResponse response)
					throws IOException, ServletException {
		// busca o writer
		PrintWriter out = response.getWriter();

		

		ShowDao dao = new ShowDao();
		ArrayList<Show> listaShow = null;
		try {
			listaShow = dao.getListShow();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		out.println("<html>");
		out.println("<body>");
		for(Show list : listaShow){
			out.println("Local: " + list.getLocal().getNome());
			out.println("Data: " + list.getData() );
		}
		
		out.println("</body>");
		out.println("</html>");

}
}
