package Servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

import DAO.LocalDao;
import DAO.ShowDao;
import Pojo.Local;
import Pojo.Show;
@WebServlet("/cadastroshow")
public class ServletCadastroShow extends HttpServlet {
	

    protected void service(HttpServletRequest request,
                        HttpServletResponse response)
                        throws IOException, ServletException {
		// busca o writer
		PrintWriter out = response.getWriter();

		// buscando os par�metros no request
		String nomeLocal = request.getParameter("local");
		String dataEmTexto = request.getParameter("data");
		
		LocalDao lDao = new LocalDao();
		Local local = null;
		try {
			local = lDao.getLocalByName(nomeLocal);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		out.println("<html>");
		out.println("<body>");
		out.println(local.getNome());
		out.println("</body>");
		out.println("</html>");
				Date data = null;
		// fazendo a convers�o da data
        try {
            Date date = (Date) new SimpleDateFormat("yyyy-mm-DD").parse(dataEmTexto);
            data = date;
        } catch (ParseException e) {
            out.println("Erro de convers�o da data");
            return; //para a execu��o do m�todo
        } catch (java.text.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        Show show  = new Show();
		show.setData(data);
	

		ShowDao dao = new ShowDao();
		try {
			dao.cadastrarshow(local, show);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		out.println("<html>");
		out.println("<body>");
		out.println("Show cadastrado com sucesso");
		out.println("</body>");
		out.println("</html>");

	}
}
