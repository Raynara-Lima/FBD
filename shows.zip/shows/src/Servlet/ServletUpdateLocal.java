package Servlet;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Pojo.Local;
import DAO.LocalDao;
@WebServlet("/updatelocal")
public class ServletUpdateLocal extends HttpServlet {
	protected void service(HttpServletRequest request,
			HttpServletResponse response)
					throws IOException, ServletException {
		// busca o writer
		PrintWriter out = response.getWriter();

		// buscando os par�metros no request
		String nome = request.getParameter("nome");
		String nomeLocal = request.getParameter("nomeLocal");
		String cap = request.getParameter("capacidade");
		int capacidade = Integer.parseInt(cap);
	

		LocalDao dao = new LocalDao();
		Local local = null;
		try {
			local = dao.getLocalByName(nome);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		local.setNome(nomeLocal);
		
		local.setCapacidade(capacidade);
		try {
			dao.updateLocal(local);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		out.println("<html>");
		out.println("<body>");
		out.println("local " + local.getNome() +
				" atualizado com sucesso");
		out.println("</body>");
		out.println("</html>");

	}
}
