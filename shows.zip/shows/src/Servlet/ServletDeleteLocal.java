package Servlet;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.LocalDao;
import Pojo.Local;


@WebServlet("/deletarlocal")
public class ServletDeleteLocal extends HttpServlet {
	protected void service(HttpServletRequest request,
			HttpServletResponse response)
					throws IOException, ServletException {
		// busca o writer
		PrintWriter out = response.getWriter();
		
		 String nome = request.getParameter("nomeLocal");
		
		 boolean result = false; 
		LocalDao dao = new LocalDao();
		Local local = null;
		try {
			local = dao.getLocalByName(nome);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			result = dao.deleteLocal(local.getId_local());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		out.println("<html>");
		out.println("<body>");
		if(result == true){
			out.println("Local exclu�do com sucesso");
		}else{
			out.println("N�o foi poss�vel excluir o local");
		}
		
		
		out.println("</body>");
		out.println("</html>");

}
}
