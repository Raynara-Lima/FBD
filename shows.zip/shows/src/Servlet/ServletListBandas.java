package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Pojo.Banda;
import DAO.BandaDao;
@WebServlet("/listbandas")
public class ServletListBandas extends HttpServlet {
	protected void service(HttpServletRequest request,
			HttpServletResponse response)
					throws IOException, ServletException {
		// busca o writer
		PrintWriter out = response.getWriter();

		

		BandaDao dao = new BandaDao();
		ArrayList<Banda> listaLocais = null;
		try {
			listaLocais = dao.getListLocais();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		out.println("<html>");
		out.println("<body>");
		for(Banda b : listaLocais){
			out.println("Nome: " + b.getNome() + " G�nero: " + b.getGenero().name());
		}
		
		out.println("</body>");
		out.println("</html>");

}
}

