package Servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Pojo.Local;
import DAO.LocalDao;
@WebServlet("/listlocais")
public class ServletListarLocais extends HttpServlet {
	protected void service(HttpServletRequest request,
			HttpServletResponse response)
					throws IOException, ServletException {
		// busca o writer
		PrintWriter out = response.getWriter();

		

		LocalDao dao = new LocalDao();
		ArrayList<Local> listaLocais = null;
		try {
			listaLocais = dao.getListLocais();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		out.println("<html>");
		out.println("<body>");
		for(Local l : listaLocais){
			out.println("Nome: " + l.getNome() + " Capacidade: " + l.getCapacidade());
		}
		
		out.println("</body>");
		out.println("</html>");

}
}
