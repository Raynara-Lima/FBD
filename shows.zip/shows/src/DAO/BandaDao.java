package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import JDBC.ConnectionFactory;
import Pojo.Banda;
import Pojo.Local;


public class BandaDao {
	private Connection con;
	
	public BandaDao(){
		
	}
	
	public void cadastrarBanda(Banda banda) throws ClassNotFoundException  {
        String sql = "insert into banda " +
                "(nome)" +
                " values (?)";
        this.con = new ConnectionFactory().getConnection();
        try {
            // prepared statement para inser��o
            PreparedStatement stmt = con.prepareStatement(sql);

            // seta os valores

            stmt.setString(1,banda.getNome());
           
            

            // executa
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
	public Banda getByName(String nome) throws ClassNotFoundException{
String sql = "SELECT * FROM banda WHERE nome = ?";
		
		this.con = new ConnectionFactory().getConnection();
		
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, nome);
			
			ResultSet rs = stmt.executeQuery();
			rs.next();
			
			Banda banda = new Banda();
			banda.setId_banda(rs.getInt("id_banda"));
			banda.setNome(rs.getString("nome"));
			
			
			stmt.close();
			
			return banda;
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
		
	}
	public Banda getBandaById(int id_banda) throws ClassNotFoundException{
		String sql = "SELECT * FROM banda WHERE id_banda = ?";
		
		this.con = new ConnectionFactory().getConnection();
		
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, id_banda);
			
			ResultSet rs = stmt.executeQuery();
			rs.next();
			
			Banda banda = new Banda();
			banda.setId_banda(rs.getInt("id_banda"));
			banda.setNome(rs.getString("nome"));
		
			
			stmt.close();
			
			return banda;
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	public Banda getBandaByName(String nome) throws ClassNotFoundException{
		String sql = "SELECT * FROM banda WHERE nome = ?";
		
		this.con = new ConnectionFactory().getConnection();
		
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, nome);
			
			ResultSet rs = stmt.executeQuery();
			rs.next();
			
			Banda banda = new Banda();
			banda.setId_banda(rs.getInt("id_banda"));
			banda.setNome(rs.getString("nome"));
			
			
			stmt.close();
			
			return banda;
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
		
		
	}
}
