package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import JDBC.ConnectionFactory;
import Pojo.Banda;

public class BandaDao {
	private Connection con;
	
	public BandaDao(){
		
	}
	
	public void cadastrarBanda(Banda banda) throws ClassNotFoundException  {
        String sql = "insert into banda " +
                "(nome)" +
                " values (?)";
        this.con = new ConnectionFactory().getConnection();
        try {
            // prepared statement para inser��o
            PreparedStatement stmt = con.prepareStatement(sql);

            // seta os valores

            stmt.setString(1,banda.getNome());
           
            

            // executa
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
