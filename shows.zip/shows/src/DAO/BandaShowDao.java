package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import JDBC.ConnectionFactory;
import Pojo.Banda;
import Pojo.BandaShow;
import Pojo.Local;
import Pojo.Show;;


public class BandaShowDao {
	private Connection con;
	public void addbandashow(Banda banda, Show show) throws ClassNotFoundException  {
        String sql = "insert into banda_show " +
                "(id_show, id_banda)" +
                " values (?, ?)";
        this.con = new ConnectionFactory().getConnection();
        try {
            // prepared statement para inser��o
            PreparedStatement stmt = con.prepareStatement(sql);

            // seta os valores

            stmt.setInt(1, show.getId_show());
            stmt.setInt(2, banda.getId_banda());
           
            

            // executa
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
	
	public ArrayList<BandaShow> getListBandaShow() throws ClassNotFoundException{
		String sql = "SELECT * FROM banda_show";
		ArrayList<BandaShow> listBandaShow = new ArrayList<BandaShow>();
		this.con = new ConnectionFactory().getConnection();
		
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			/*ResultSet � uma interface utilizada pra guardar
			 * dados vindos de um banco de dados.
			*Basicamente, ela guarda o resultado de uma pesquisa
			*numa estrutura de dados que pode ser percorrida,
			*de forma que voc� possa ler os dados do banco. */
			BandaDao BDao = new BandaDao();
			ShowDao SDao = new ShowDao();
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				
				Banda banda = BDao.getBandaById(rs.getInt("id_banda"));
				Show show = SDao.getLocalById(rs.getInt("id_show"));
				BandaShow bs = new BandaShow();
				bs.setBanda(banda);
				bs.setShow(show);
				
				listBandaShow.add(bs);
			}
			stmt.close();
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return listBandaShow;
		
	}
	public boolean deleteBandaShow(int id_bs) throws ClassNotFoundException{
		String sql = "DELETE FROM banda_show WHERE idShowBanda = ?";
		this.con = new ConnectionFactory().getConnection();
		
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			
			//Setar valores
			stmt.setInt(1, id_bs);
			
			int affectedRows = stmt.executeUpdate();
			stmt.close();
			
			if(affectedRows > 0) {
				return true;
			}
			return false;
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public void updateBandaShow(BandaShow bs) throws ClassNotFoundException{
		 String sql = "update banda_show set id_show = ?, id_banda = ? where idBandaShow = ?";
	        this.con = new ConnectionFactory().getConnection();
	        try {
	            // prepared statement para inser��o
	            PreparedStatement stmt = con.prepareStatement(sql);

	            // seta os valores

	            stmt.setInt(1,bs.getShow().getId_show());
	            stmt.setInt(2,bs.getBanda().getId_banda());
	            stmt.setInt(3, bs.getId_bandaShow());
	           
	            

	            // executa
	            stmt.execute();
	            stmt.close();
	        } catch (SQLException e) {
	            throw new RuntimeException(e);
	        }
	}
	
	public BandaShow getBsByIdShow(int id_show) throws ClassNotFoundException{
String sql = "SELECT * FROM banda_show WHERE id_show = ?";
		
		this.con = new ConnectionFactory().getConnection();
		BandaDao bDao = new BandaDao();
		ShowDao sDao = new ShowDao();
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, id_show);
			
			
			ResultSet rs = stmt.executeQuery();
			rs.next();
			int id_banda = rs.getInt("id_banda");
			
			
			Banda banda = bDao.getBandaById(id_banda);
			Show show = sDao.getShowById(id_show);
			
			BandaShow bs = new BandaShow();
			bs.setId_bandaShow(rs.getInt("idShowBanda"));
			bs.setBanda(banda);
			bs.setShow(show);
			
			stmt.close();
			
			return bs;
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
}
