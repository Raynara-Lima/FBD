package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import JDBC.ConnectionFactory;
import Pojo.Banda;
import Pojo.BandaShow;
import Pojo.Local;
import Pojo.Show;;


public class BandaShowDao {
	private Connection con;
	public void addbandashow(Banda banda, Show show) throws ClassNotFoundException  {
        String sql = "insert into banda_show " +
                "(id_show, id_banda)" +
                " values (?, ?)";
        this.con = new ConnectionFactory().getConnection();
        try {
            // prepared statement para inser��o
            PreparedStatement stmt = con.prepareStatement(sql);

            // seta os valores

            stmt.setInt(1, show.getId_show());
            stmt.setInt(2, banda.getId_banda());
           
            

            // executa
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
	
	public ArrayList<BandaShow> getListBandaShow() throws ClassNotFoundException{
		String sql = "SELECT * FROM banda_show";
		ArrayList<BandaShow> listBandaShow = new ArrayList<BandaShow>();
		this.con = new ConnectionFactory().getConnection();
		
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			/*ResultSet � uma interface utilizada pra guardar
			 * dados vindos de um banco de dados.
			*Basicamente, ela guarda o resultado de uma pesquisa
			*numa estrutura de dados que pode ser percorrida,
			*de forma que voc� possa ler os dados do banco. */
			BandaDao BDao = new BandaDao();
			ShowDao SDao = new ShowDao();
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				
				Banda banda = BDao.getBandaById(rs.getInt("id_banda"));
				Show show = SDao.getLocalById(rs.getInt("id_show"));
				BandaShow bs = new BandaShow();
				bs.setBanda(banda);
				bs.setShow(show);
				
				listBandaShow.add(bs);
			}
			stmt.close();
		}catch(SQLException e) {
			System.err.println(e.getMessage());
		}finally {
			try {
				this.con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return listBandaShow;
		
	}

}
