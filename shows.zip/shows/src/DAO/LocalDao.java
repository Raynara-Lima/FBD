package DAO;

public class LocalDao {

}
