package Pojo;

import java.util.Date;

public class Show {
	private Date data;
	private Local local;
	
	public Show(Date data, Local local){
		this.data = data;
		this.setLocal(local);
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public Local getLocal() {
		return local;
	}

	public void setLocal(Local local) {
		this.local = local;
	}
}
