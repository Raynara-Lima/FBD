package Pojo;

import java.util.Date;

public class Show {
	private int id_show;
	private Date data;
	private Local local;
	
	public Show(){
		
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public Local getLocal() {
		return local;
	}

	public void setLocal(Local local) {
		this.local = local;
	}

	public int getId_show() {
		return id_show;
	}

	public void setId_show(int id_show) {
		this.id_show = id_show;
	}
}
