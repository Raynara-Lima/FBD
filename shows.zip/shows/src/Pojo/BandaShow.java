package Pojo;

public class BandaShow {
	private Banda banda;
	private Show show;
	
	
	public BandaShow(Banda banda, Show show){
		this.banda = banda;
		this.show = show;
	}
	
	public Show getShow() {
		return show;
	}
	public void setShow(Show show) {
		this.show = show;
	}
	public Banda getBanda() {
		return banda;
	}
	public void setBanda(Banda banda) {
		this.banda = banda;
	}
}
