package Pojo;

 //enum Genero { ROCK, FORR�, AX�, SERTANEJO, POP}	

public class Banda {
	private int id_banda;
	private String nome;
	//private Genero genero;
	
	public Banda( ){
		
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
//	public Genero getGenero() {
//		return genero;
//	}

	public int getId_banda() {
		return id_banda;
	}

	public void setId_banda(int id_banda) {
		this.id_banda = id_banda;
	}
	
	
	
	
}
