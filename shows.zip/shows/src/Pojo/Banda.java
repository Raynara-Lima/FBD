package Pojo;

 //enum Genero { ROCK, FORR�, AX�, SERTANEJO, POP}	

public class Banda {
	private String nome;
	//private Genero genero;
	
	public Banda(){
		
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
//	public Genero getGenero() {
//		return genero;
//	}
	
	
	
	
}
