package livraria

class UsuarioController {

    def index() {
        def lista = Usuario.list()
        render(view: "/usuario/index", model: [usuarios: lista])
    }

    def adicionar (){

        Usuario novoUsuario = new Usuario()
        novoUsuario.nome = ''
        novoUsuario.login = ''
        novoUsuario.senha = ''
        render(template: "/usuario/form", model : [usuario:  novoUsuario])
    }
    def lista(){
        def lista = Usuario.list()
        render(template: "/usuario/lista", model: [usuarios: lista])
    }
    def salvar(){
        Usuario usuario = null
        if(params.id){
            usuario = Usuario.get(params.id)
        }else{
            usuario = new Usuario()
        }

        usuario.nome = params.nome
        usuario.login = params.login
        usuario.senha = params.senha

        usuario.validate()
        if(!usuario.hasErrors()){
            usuario.save(flush: true)
            render("Salvo com sucesso")
        }else {
            render("Não foi possível salvar")
        }
    }

    def alterar(){
        Usuario usuario = Usuario.get(params.id)
        render(template: "/usuario/form", model: [usuario: usuario])
    }
    def excluir(){
        Usuario usuario = Usuario.get(params.id)
        usuario.delete(flush: true)
        def lista = Usuario.list()
        render(template: "/usuario/lista", model: [usuarios: lista])
    }
}
