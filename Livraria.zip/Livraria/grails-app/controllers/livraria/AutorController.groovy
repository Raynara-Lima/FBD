package livraria

class AutorController {


    def index() {
        def lista = Autor.list()
        render(view: "/autor/index", model: [autores: lista])
    }

    def adicionar (){

        Autor novoAutor = new Autor()
        novoAutor.nome = ''
        novoAutor.nascimento = null
        render(template: "/autor/form", model : [autor:  novoAutor])
    }
    def lista(){
        def lista = Autor.list()
        render(template: "/autor/lista", model: [autores: lista])
    }
    def salvar(){
        Autor autor = null
        if(params.id){
            autor = Autor.get(params.id)
        }else{
            autor = new Autor()
        }

        autor.nome = params.nome
        autor.nascimento = params.nascimento


        autor.validate()
        if(!autor.hasErrors()){
            autor.save(flush: true)
            render("Salvo com sucesso")
        }else {
            render("Não foi possível salvar")
        }
    }

    def alterar(){
        Autor autor = Autor.get(params.id)
        render(template: "/autor/form", model: [autor: autor])
    }
    def excluir(){
        Autor autor = Autor.get(params.id)
        autor.delete(flush: true)
        def lista = Autor.list()
        render(template: "/autor/lista", model: [autores: lista])
    }
}
