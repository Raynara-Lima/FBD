package livraria

class Livro {

    String titulo
    Float valor
    Autor autor
    static constraints = {
    }
    static  mapping = {
        autor column: "id_autor"
    }
}
