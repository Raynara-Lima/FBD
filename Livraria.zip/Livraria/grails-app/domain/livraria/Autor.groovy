package livraria

class Autor {
    String nome
    Date nascimento

    static  hasMany = [livros:Livro]
    static constraints = {
    }
}
