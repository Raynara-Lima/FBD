package livraria

class Usuario {
    String nome
    String login
    String senha

    static constraints = {
    }
}
